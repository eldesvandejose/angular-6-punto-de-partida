export class Member {
  id: string;
  doi: string;
  nombre: string;
  avatar: any;
  fecha_de_ingreso: string;
  genero: string;
  activo: string;

  constructor(id, doi, nombre, fecha, genero, activo, avatarName) {
    this.id = id;
    this.doi = doi;
    this.nombre = nombre;
    this.fecha_de_ingreso = fecha;
    this.genero = genero;
    this.activo = activo;
    this.avatar = avatarName;
  }
}
