<?php
  include_once ('db_conn.php');

  // Recuperamos los datos del usuario
  $datosDeUsuario = json_decode($_POST["User"], true);

  /* Determinamos si el nombre del avatar debe ser "recortado" para adaptarlo al formato en que se graban.
  Esto sucede por el javascript en la edición. */
  if ($datosDeUsuario["id"] != "0") {
    $posicionDeInicioNombreReal = strpos($datosDeUsuario["avatar"], "avatares/");
    if ($posicionDeInicioNombreReal !== 0) {
      $datosDeUsuario["avatar"] = substr($datosDeUsuario["avatar"], $posicionDeInicioNombreReal);
    }
  }

  $numeroDeError = "0";

  /* ALTA NUEVA */
  if ($datosDeUsuario["id"] == "0") { // Nueva inserción
    // Si tiene un avatar le creamos un nombre.
    // Si no lo tiene el nombre es sin_avatar.jpg
    if (isset($_FILES["Avatar"])) {
      $datosDeUsuario["nombreDeAvatar"] = "avatares/".md5(uniqid()).".jpg";
    } else {
      $datosDeUsuario["nombreDeAvatar"] = "avatares/sin_avatar.jpg";
    }
    $consulta = "INSERT INTO socios (";
    $consulta .= "doi, nombre, fecha_de_ingreso, genero, avatar, activo ";
    $consulta .= ") VALUES (";
    $consulta .= ":doi, :nombre, :fecha_de_ingreso, :genero, :avatar, :activo);";

    $hacerConsulta = $conexion->prepare($consulta); // Se crea un objeto PDOStatement.
    $hacerConsulta->bindParam("doi", $datosDeUsuario['doi']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("nombre", $datosDeUsuario['nombre']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("fecha_de_ingreso", $datosDeUsuario['fecha_de_ingreso']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("genero", $datosDeUsuario['genero']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("avatar", $datosDeUsuario['nombreDeAvatar']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindValue("activo", "S"); // Se asigna un valor para la consulta.
    try {
      $hacerConsulta->execute(); // Se ejecuta la consulta.
    } catch (PDOException $e) {
      $numeroDeError = $e;
    }
    $hacerConsulta->closeCursor(); // Se libera el recurso.
    
    if ($numeroDeError == "0" && isset($_FILES["Avatar"])) {
      move_uploaded_file($_FILES["Avatar"]["tmp_name"], $datosDeUsuario["nombreDeAvatar"]);
    }
  } else { /* EDICIÓN DE REGISTRO EXISTENTE */
    if (isset($_FILES["Avatar"])) {
      $datosDeUsuario["nombreDeAvatar"] = "avatares/".md5(uniqid()).".jpg";
    } else {
      $datosDeUsuario["nombreDeAvatar"] = $datosDeUsuario["avatar"];
    }
    /* Se lee el nombre actual del avatar. Si coincide con el nombre enviado, no habrá que cambiarlo. */
    $consulta = "SELECT avatar ";
    $consulta .= "FROM socios ";
    $consulta .= "WHERE id = '".$datosDeUsuario["id"]."';";
    $hacerConsulta = $conexion->query($consulta);
    $nombreAnteriorDelAvatar = $hacerConsulta->fetch(PDO::FETCH_ASSOC)["avatar"];
    $hacerConsulta->closeCursor();

    /* Se intenta actualizar el registro. Puede fallar, si el doi está repetido, pq es campo único. */
    $consulta = "UPDATE socios SET ";
    $consulta .= "doi = :doi, ";
    $consulta .= "nombre = :nombre, ";
    $consulta .= "fecha_de_ingreso = :fecha_de_ingreso, ";
    $consulta .= "genero = :genero, ";
    $consulta .= "avatar = :avatar, ";
    $consulta .= "activo = :activo ";
    $consulta .= "WHERE id = :id;";
    $hacerConsulta = $conexion->prepare($consulta); // Se crea un objeto PDOStatement.
    $hacerConsulta->bindParam("id", $datosDeUsuario['id']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("doi", $datosDeUsuario['doi']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("nombre", $datosDeUsuario['nombre']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("fecha_de_ingreso", $datosDeUsuario['fecha_de_ingreso']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("genero", $datosDeUsuario['genero']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("avatar", $datosDeUsuario['nombreDeAvatar']); // Se asigna un valor para la consulta.
    $hacerConsulta->bindParam("activo", $datosDeUsuario['activo']); // Se asigna un valor para la consulta.

    try {
      $hacerConsulta->execute(); // Se ejecuta la consulta.
    } catch (PDOException $e) {
      $numeroDeError = $e;
    }
    $hacerConsulta->closeCursor(); // Se libera el recurso.

    if ($numeroDeError == "0") { // Si se ha podido grabar el registro, se actualiza, si procede, el avatar.
      if (isset($_FILES["Avatar"])) {
        move_uploaded_file($_FILES["Avatar"]["tmp_name"], $datosDeUsuario["nombreDeAvatar"]);
        if (strpos($nombreAnteriorDelAvatar, "sin_avatar") === false) {
          unlink($nombreAnteriorDelAvatar);
        }
      } else {
        if (strpos($datosDeUsuario["nombreDeAvatar"], "sin_avatar") > -1 && strpos($nombreAnteriorDelAvatar, "sin_avatar") === false) {
          unlink($nombreAnteriorDelAvatar);
        }
      }
    }
  } // FIN DE COMPROBACIÓN DE NUEVO O EDICIÓN

  $respuesta = json_encode($numeroDeError);
  echo $respuesta;
?>
